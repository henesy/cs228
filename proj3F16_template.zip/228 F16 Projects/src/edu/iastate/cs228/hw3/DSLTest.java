package edu.iastate.cs228.hw3;

public class DSLTest 
{
	public static void main(String args[])
	{
		// Conduct your own JUnit tests in a class, say, HW3Test.
	}
}
